$(document).ready(function(){
    $("#wrap img").click(function(){
        var newsrc = $(this).attr("src");
        var newalt = $(this).attr("alt");
        newsrc = newsrc.replace("thumb_","");
        $("#modalcont>img").attr("src",newsrc);
        $("#modalheader>p").text(newalt);
        $("#modal").fadeIn();
        $("#modalbox").animate({
            opacity: 1,
            marginTop: "-15px"
        });
        $("#modalbox").animate({
            marginTop: 0
        },200);
    });
    // #wrap안에있는 img를 눌렀을때
        // 방금누른그것(this)에서 src와 alt의 값을 추출
            // 예) images/thumb_image3.jpg
            //      "thumb_"를 ""로 교체하면
            //     images/image3.jpg 가 된다.
        // src의 값에서 "thumb_"라는 부분을 ""로 교체한다.
        // #modalcont>img의 속성중에 src라는 속성에
        // 아까 알아낸 원본이미지의 주소를 넣는다.
        // #modalheader>p의 내용으로 아까 알아낸 alt값을 넣는다.
        // #modal을 보여준다.
    
    function modalclose(){
        $("#modal").fadeOut();
        $("#modalbox").animate({
            marginTop: "-15px"
        },200);
        $("#modalbox").animate({
            opacity: 0,
            marginTop: "100px"
        });
    }
    
    $("#close").click(function(){
        modalclose();
    });
    // #close를 눌렀을때
        // #modal을 숨긴다.
    
    $("#modal").click(function(){
        modalclose();
    });
    
    $("#modalbox").click(function(e){
        e.stopPropagation();
    });
    
    
});











